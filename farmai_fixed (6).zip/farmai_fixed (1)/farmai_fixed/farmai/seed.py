"""
Run this once after db.create_all() to seed the schemes table:
    python seed.py
"""
from app import app
from extensions import db
from routes.schemes import seed_schemes

with app.app_context():
    db.create_all()
    seed_schemes()
    print("✅ Database tables created and schemes seeded successfully!")
