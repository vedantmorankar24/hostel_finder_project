from flask import Flask
from config import Config
from extensions import db
from routes.auth import auth_bp
from routes.disease import disease_bp
from routes.weather import weather_bp
from routes.schemes import schemes_bp
from routes.main import main_bp
from routes.chatbot import chatbot_bp
from routes.prices import prices_bp

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)

app.register_blueprint(main_bp)
app.register_blueprint(auth_bp, url_prefix='/auth')
app.register_blueprint(disease_bp, url_prefix='/disease')
app.register_blueprint(weather_bp, url_prefix='/weather')
app.register_blueprint(schemes_bp, url_prefix='/schemes')
app.register_blueprint(chatbot_bp, url_prefix='/chatbot')
app.register_blueprint(prices_bp, url_prefix='/prices')

with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True)