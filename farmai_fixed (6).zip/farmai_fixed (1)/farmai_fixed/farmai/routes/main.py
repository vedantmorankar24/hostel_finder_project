from flask import Blueprint, render_template, session, redirect, url_for, flash
from models import User, DiseaseScan, SchemeSearch

main_bp = Blueprint('main', __name__)


@main_bp.route('/')
def index():
    return render_template('index.html')


@main_bp.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        flash('Please login to view your dashboard.', 'warning')
        return redirect(url_for('auth.login'))

    user = User.query.get(session['user_id'])

    if user is None:
        # Session has stale user_id — clear it and redirect to login
        session.clear()
        flash('Session expired. Please login again.', 'warning')
        return redirect(url_for('auth.login'))

    recent_scans = DiseaseScan.query.filter_by(user_id=user.id)\
                    .order_by(DiseaseScan.scanned_at.desc()).limit(5).all()

    return render_template('dashboard.html', user=user, recent_scans=recent_scans)