import json
from flask import Blueprint, render_template, request, jsonify, current_app
from groq import Groq
from datetime import datetime

prices_bp = Blueprint('prices', __name__)

# ── Static mandi price data (realistic Maharashtra prices April 2026) ─────────
# Structure: crop -> { unit, markets: { market_name: {min, max, modal} } }
MANDI_PRICES = {
    'onion':      { 'mr':'कांदा',    'unit':'Quintal', 'markets':{ 'Nashik':{'min':800,'max':1400,'modal':1100}, 'Pune':{'min':900,'max':1500,'modal':1200}, 'Lasalgaon':{'min':750,'max':1350,'modal':1050}, 'Mumbai':{'min':1200,'max':1800,'modal':1500}, 'Aurangabad':{'min':800,'max':1300,'modal':1050} } },
    'tomato':     { 'mr':'टोमॅटो',   'unit':'Quintal', 'markets':{ 'Nashik':{'min':600,'max':1800,'modal':1200}, 'Pune':{'min':700,'max':2000,'modal':1400}, 'Nagpur':{'min':500,'max':1600,'modal':1000}, 'Mumbai':{'min':1000,'max':2400,'modal':1800}, 'Solapur':{'min':600,'max':1700,'modal':1100} } },
    'wheat':      { 'mr':'गहू',      'unit':'Quintal', 'markets':{ 'Nashik':{'min':2200,'max':2600,'modal':2400}, 'Pune':{'min':2300,'max':2700,'modal':2500}, 'Nagpur':{'min':2100,'max':2500,'modal':2300}, 'Latur':{'min':2200,'max':2600,'modal':2400}, 'Aurangabad':{'min':2150,'max':2550,'modal':2350} } },
    'cotton':     { 'mr':'कापूस',    'unit':'Quintal', 'markets':{ 'Nashik':{'min':6500,'max':7200,'modal':6800}, 'Nagpur':{'min':6400,'max':7100,'modal':6750}, 'Aurangabad':{'min':6300,'max':7000,'modal':6650}, 'Amravati':{'min':6450,'max':7150,'modal':6800}, 'Jalgaon':{'min':6350,'max':7050,'modal':6700} } },
    'soybean':    { 'mr':'सोयाबीन',  'unit':'Quintal', 'markets':{ 'Nashik':{'min':4200,'max':4800,'modal':4500}, 'Latur':{'min':4100,'max':4700,'modal':4400}, 'Aurangabad':{'min':4150,'max':4750,'modal':4450}, 'Nagpur':{'min':4050,'max':4650,'modal':4350}, 'Pune':{'min':4300,'max':4900,'modal':4600} } },
    'maize':      { 'mr':'मका',      'unit':'Quintal', 'markets':{ 'Nashik':{'min':1800,'max':2200,'modal':2000}, 'Pune':{'min':1900,'max':2300,'modal':2100}, 'Nagpur':{'min':1750,'max':2150,'modal':1950}, 'Aurangabad':{'min':1800,'max':2200,'modal':2000}, 'Solapur':{'min':1750,'max':2150,'modal':1950} } },
    'sugarcane':  { 'mr':'ऊस',       'unit':'Tonne',   'markets':{ 'Nashik':{'min':3100,'max':3400,'modal':3200}, 'Pune':{'min':3150,'max':3450,'modal':3300}, 'Kolhapur':{'min':3200,'max':3500,'modal':3350}, 'Solapur':{'min':3050,'max':3350,'modal':3200}, 'Satara':{'min':3100,'max':3400,'modal':3250} } },
    'rice':       { 'mr':'भात',      'unit':'Quintal', 'markets':{ 'Nashik':{'min':2100,'max':2800,'modal':2400}, 'Pune':{'min':2200,'max':2900,'modal':2500}, 'Nagpur':{'min':2000,'max':2700,'modal':2350}, 'Mumbai':{'min':2400,'max':3200,'modal':2800}, 'Ratnagiri':{'min':2200,'max':3000,'modal':2600} } },
    'groundnut':  { 'mr':'शेंगदाणे', 'unit':'Quintal', 'markets':{ 'Nashik':{'min':5500,'max':6500,'modal':6000}, 'Pune':{'min':5600,'max':6600,'modal':6100}, 'Solapur':{'min':5400,'max':6400,'modal':5900}, 'Latur':{'min':5450,'max':6450,'modal':5950}, 'Jalgaon':{'min':5350,'max':6350,'modal':5850} } },
    'potato':     { 'mr':'बटाटा',    'unit':'Quintal', 'markets':{ 'Nashik':{'min':1200,'max':2000,'modal':1600}, 'Pune':{'min':1300,'max':2100,'modal':1700}, 'Mumbai':{'min':1600,'max':2400,'modal':2000}, 'Nagpur':{'min':1100,'max':1900,'modal':1500}, 'Aurangabad':{'min':1150,'max':1950,'modal':1550} } },
    'grapes':     { 'mr':'द्राक्ष',  'unit':'Kg',      'markets':{ 'Nashik':{'min':40,'max':120,'modal':75}, 'Pune':{'min':50,'max':140,'modal':90}, 'Mumbai':{'min':60,'max':160,'modal':100}, 'Sangli':{'min':35,'max':110,'modal':70}, 'Satara':{'min':38,'max':115,'modal':72} } },
    'pomegranate':{ 'mr':'डाळिंब',   'unit':'Kg',      'markets':{ 'Nashik':{'min':80,'max':180,'modal':120}, 'Pune':{'min':90,'max':200,'modal':140}, 'Mumbai':{'min':100,'max':220,'modal':160}, 'Solapur':{'min':75,'max':170,'modal':110}, 'Ahmednagar':{'min':78,'max':175,'modal':115} } },
    'garlic':     { 'mr':'लसूण',     'unit':'Quintal', 'markets':{ 'Nashik':{'min':4000,'max':7000,'modal':5500}, 'Pune':{'min':4200,'max':7200,'modal':5700}, 'Mumbai':{'min':5000,'max':8000,'modal':6500}, 'Indore':{'min':3800,'max':6800,'modal':5300}, 'Kota':{'min':3600,'max':6600,'modal':5100} } },
    'turmeric':   { 'mr':'हळद',      'unit':'Quintal', 'markets':{ 'Nashik':{'min':7000,'max':10000,'modal':8500}, 'Sangli':{'min':6800,'max':9800,'modal':8300}, 'Pune':{'min':7200,'max':10200,'modal':8700}, 'Erode':{'min':6500,'max':9500,'modal':8000}, 'Nizamabad':{'min':6600,'max':9600,'modal':8100} } },
}

CROP_EMOJIS = {
    'onion':'🧅','tomato':'🍅','wheat':'🌾','cotton':'🪴','soybean':'🫘',
    'maize':'🌽','sugarcane':'🎋','rice':'🍚','groundnut':'🥜','potato':'🥔',
    'grapes':'🍇','pomegranate':'🍎','garlic':'🧄','turmeric':'🟡'
}

TREND_DATA = {
    'onion':{'trend':'up','change':'+12%','reason':'Export demand up'},
    'tomato':{'trend':'down','change':'-8%','reason':'Seasonal oversupply'},
    'wheat':{'trend':'stable','change':'+1%','reason':'MSP stable'},
    'cotton':{'trend':'up','change':'+5%','reason':'Mill buying active'},
    'soybean':{'trend':'down','change':'-3%','reason':'Import pressure'},
    'maize':{'trend':'stable','change':'+2%','reason':'Poultry demand steady'},
    'sugarcane':{'trend':'stable','change':'+0%','reason':'FRP fixed by govt'},
    'rice':{'trend':'up','change':'+4%','reason':'Low stock in markets'},
    'groundnut':{'trend':'up','change':'+7%','reason':'Oil demand high'},
    'potato':{'trend':'down','change':'-5%','reason':'Good harvest this season'},
    'grapes':{'trend':'up','change':'+15%','reason':'Export season active'},
    'pomegranate':{'trend':'stable','change':'+2%','reason':'Stable retail demand'},
    'garlic':{'trend':'up','change':'+20%','reason':'Low production last year'},
    'turmeric':{'trend':'up','change':'+9%','reason':'Pharma export demand'},
}


@prices_bp.route('/')
def index():
    today = datetime.now().strftime('%d %B %Y')
    return render_template('prices.html', crops=MANDI_PRICES, today=today)


@prices_bp.route('/data')
def price_data():
    crop = request.args.get('crop', 'onion').lower()
    if crop not in MANDI_PRICES:
        return jsonify({'success': False, 'message': 'Crop not found'}), 404
    data   = MANDI_PRICES[crop]
    trend  = TREND_DATA.get(crop, {'trend':'stable','change':'0%','reason':''})
    emoji  = CROP_EMOJIS.get(crop, '🌱')
    return jsonify({
        'success': True, 'crop': crop, 'emoji': emoji,
        'marathi': data['mr'], 'unit': data['unit'],
        'markets': data['markets'], 'trend': trend,
        'updated': datetime.now().strftime('%d %b %Y, %I:%M %p')
    })


@prices_bp.route('/advice', methods=['POST'])
def price_advice():
    """AI gives selling advice based on current price and trend"""
    data     = request.get_json()
    crop     = data.get('crop', 'onion')
    ui_lang  = data.get('ui_lang', 'mr')
    modal    = data.get('modal_price', 0)
    trend    = data.get('trend', 'stable')
    change   = data.get('change', '0%')

    crop_info = MANDI_PRICES.get(crop, {})
    crop_name = crop_info.get('mr', crop)

    if ui_lang == 'mr':
        lang_instr = 'फक्त मराठीत उत्तर द्या.'
        prompt = f"""{lang_instr}
तुम्ही एक अनुभवी कृषी बाजार सल्लागार आहात.
पीक: {crop_name} ({crop})
सध्याची बाजारभाव (Modal): ₹{modal} प्रति {crop_info.get('unit','Quintal')}
किंमत ट्रेंड: {trend} ({change} बदल)

शेतकऱ्याला 3-4 वाक्यांमध्ये सल्ला द्या:
1. आत्ता विकावे की थांबावे?
2. सर्वोत्तम बाजार कोणता?
3. पुढील 2 आठवड्यात काय होईल?

साध्या मराठीत, इमोजी वापरून उत्तर द्या."""
    elif ui_lang == 'hi':
        lang_instr = 'केवल हिंदी में जवाब दें।'
        prompt = f"""{lang_instr}
आप एक अनुभवी कृषि बाजार सलाहकार हैं।
फसल: {crop} | मंडी भाव: ₹{modal} प्रति {crop_info.get('unit','Quintal')} | ट्रेंड: {trend} ({change})
किसान को 3-4 वाक्यों में सलाह दें: अभी बेचें या रुकें? सबसे अच्छी मंडी? अगले 2 हफ्ते में क्या होगा?"""
    else:
        prompt = f"""You are an expert agricultural market advisor.
Crop: {crop} | Modal price: ₹{modal} per {crop_info.get('unit','Quintal')} | Trend: {trend} ({change})
Give farmer advice in 3-4 sentences: Sell now or wait? Best market? What will happen in next 2 weeks?"""

    try:
        client = Groq(api_key=current_app.config['GROQ_API_KEY'])
        resp   = client.chat.completions.create(
            model    = 'llama-3.3-70b-versatile',
            messages = [{'role': 'user', 'content': prompt}],
            max_tokens  = 300,
            temperature = 0.6,
        )
        advice = resp.choices[0].message.content.strip()
        return jsonify({'success': True, 'advice': advice})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500