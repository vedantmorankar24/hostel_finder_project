// FarmAI — main.js

function toggleMenu() {
  document.getElementById('mobileMenu').classList.toggle('open');
}

// Auto-hide flash messages
document.querySelectorAll('.flash').forEach(el => {
  setTimeout(() => el.style.display = 'none', 4000);
});
