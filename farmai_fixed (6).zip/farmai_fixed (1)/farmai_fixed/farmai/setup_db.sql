-- Run this in MySQL before starting the app
-- mysql -u root -p < setup_db.sql

CREATE DATABASE IF NOT EXISTS farmai_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE farmai_db;

-- SQLAlchemy will auto-create tables via db.create_all()
-- But you can also run this to verify the DB exists:
SHOW DATABASES LIKE 'farmai_db';

-- After running the app once (db.create_all()), seed schemes:
-- Run: python seed.py
