# 🌾 FarmAI — Smart Farmer Assistant

> Hackathon 2026 · Nashik, Maharashtra
> Built with: HTML · CSS · JavaScript · Flask · MySQL · Claude AI

---

## 📁 Project Structure

```
farmai/
├── app.py                  # Flask app entry point
├── config.py               # Configuration (DB, API keys)
├── extensions.py           # SQLAlchemy instance
├── models.py               # MySQL database models
├── seed.py                 # DB seeder script
├── setup_db.sql            # MySQL setup script
├── requirements.txt
├── .env.example            # Copy to .env and fill values
│
├── routes/
│   ├── main.py             # Home & Dashboard
│   ├── auth.py             # Register / Login / Logout
│   ├── disease.py          # Crop Disease Detection (Claude Vision)
│   ├── weather.py          # Weather + Crop Advisor
│   └── schemes.py          # Government Schemes
│
├── templates/
│   ├── base.html           # Navbar, footer, flash messages
│   ├── index.html          # Landing page
│   ├── dashboard.html      # User dashboard
│   ├── disease.html        # Disease detection page
│   ├── weather.html        # Weather crop advisor page
│   ├── schemes.html        # Government schemes page
│   ├── login.html          # Login page
│   └── register.html       # Registration page
│
└── static/
    ├── css/main.css        # Full stylesheet
    ├── js/main.js          # Frontend JS
    └── uploads/            # Uploaded crop images (auto-created)
```

---

## 🚀 Setup & Run

### 1. Clone & Install

```bash
git clone <your-repo>
cd farmai
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Setup MySQL

```bash
# Start MySQL and create the database
mysql -u root -p < setup_db.sql
```

### 3. Configure Environment

```bash
cp .env.example .env
# Edit .env and fill in:
#   MYSQL_PASSWORD=your_password
#   ANTHROPIC_API_KEY=sk-ant-...
#   OPENWEATHER_API_KEY=...     (optional, free at openweathermap.org)
```

> **Get Anthropic API key:** https://console.anthropic.com  
> **Get OpenWeather key (free):** https://openweathermap.org/api

### 4. Initialize Database & Seed Schemes

```bash
python seed.py
```

### 5. Run the App

```bash
python app.py
```

Visit: **http://localhost:5000**

---

## ✨ Features

### 🔬 Feature 1 — Crop Disease Detection
- Upload any crop photo (JPG/PNG)
- Claude Vision AI identifies disease, severity, confidence
- Returns 4 step-by-step treatment solutions
- Scan history saved per user in MySQL

### 🌦️ Feature 2 — Weather Crop Advisor
- Select from 7 Maharashtra cities
- Live weather via OpenWeatherMap API (fallback to static data)
- Claude AI recommends top 4 crops with match % and reasoning
- Risk alert + weekly farming tip

### 📋 Feature 3 — Government Schemes Finder
- Filter by state, land size, crop type
- 7 pre-seeded schemes (PM-KISAN, PMFBY, KCC, etc.)
- Direct apply links to official government websites
- Search history saved per user

### 👤 User Accounts
- Register with phone number + password
- Profile stores: state, district, land size, primary crop
- Dashboard with scan history and stats

---

## 🗄️ Database Schema

| Table | Purpose |
|---|---|
| `users` | Farmer accounts |
| `disease_scans` | Crop scan history per user |
| `scheme_searches` | Scheme search logs |
| `schemes` | Government schemes data |

---

## 🔌 API Endpoints

| Method | Route | Description |
|---|---|---|
| GET | `/` | Landing page |
| GET/POST | `/auth/register` | Register |
| GET/POST | `/auth/login` | Login |
| GET | `/auth/logout` | Logout |
| GET | `/dashboard` | User dashboard |
| GET | `/disease/` | Disease detection page |
| POST | `/disease/analyze` | Analyze crop image (Claude AI) |
| GET | `/disease/history` | User scan history (JSON) |
| GET | `/weather/` | Weather advisor page |
| GET | `/weather/data?city=nashik` | Weather data (JSON) |
| POST | `/weather/recommend` | AI crop recommendations (JSON) |
| GET | `/schemes/` | Schemes page |
| POST | `/schemes/search` | Filter schemes (JSON) |

---

## 🤝 Team Roles

| Member | Responsibility |
|---|---|
| Member 1 | Frontend — HTML/CSS all pages, responsive design |
| Member 2 | Backend — Flask routes, MySQL models |
| Member 3 | AI Integration — Claude API (disease + crop advisor) |
| Member 4 | Database — MySQL schema, seeding, optimization |
| Member 5 | Schemes data, testing, demo presentation |

---

## 💡 Hackathon Tips

- Use `debug=True` in `app.py` during development
- Test disease detection with tomato/wheat leaf images from Google
- The weather feature works even without OpenWeatherMap key (static fallback)
- Schemes are fully functional without any API key

---

## 📞 Support
Built for farmers of Nashik, Maharashtra 🌾
