import json
from flask import Blueprint, render_template, request, Response, stream_with_context, current_app
from groq import Groq

chatbot_bp = Blueprint('chatbot', __name__)


def build_system_prompt(lang='mr'):
    lang_rules = {
        'mr': "तुम्ही फक्त मराठीत उत्तर द्यायचे आहे. औषधांची नावे इंग्रजीत लिहा बाकी सर्व मराठीत.",
        'hi': "आप केवल हिंदी में जवाब दें। दवाओं के नाम अंग्रेजी में लिख सकते हैं, बाकी सब हिंदी में।",
        'en': "Respond in simple clear English.",
    }

    disease_format = {
        'mr': """जेव्हा शेतकरी पिकाचा फोटो पाठवतो तेव्हा नेहमी हे सांगा:
🌱 पीक: (पिकाचे नाव)
🦠 रोगाचे नाव: (रोगाचे पूर्ण नाव)
⚠️ तीव्रता: उच्च / मध्यम / कमी
📉 नुकसान: (उपचार न केल्यास किती % नुकसान)

🔍 लक्षणे:
• लक्षण १
• लक्षण २
• लक्षण ३

💊 औषधे:
1. औषधाचे नाव — मात्रा (उदा. Mancozeb 75% WP — 2.5g प्रति लिटर पाण्यात)
   वापरण्याची वेळ: दर 7 दिवसांनी 3 आठवडे

2. दुसरे औषध — मात्रा
   वापरण्याची वेळ: ...

🌿 घरगुती उपाय: (सहज उपलब्ध घरातील उपाय)

🛠️ उपचार पायऱ्या:
पाऊल १: आजच करायची कृती
पाऊल २: 2-3 दिवसांत करायची कृती
पाऊल ३: साप्ताहिक कृती
पाऊल ४: दीर्घकालीन प्रतिबंध

🛡️ पुढील हंगामासाठी प्रतिबंध:
• सल्ला १
• सल्ला २

💪 प्रोत्साहन देणारा संदेश""",

        'hi': """जब किसान फसल की फोटो भेजें तो हमेशा यह बताएं:
🌱 फसल: (फसल का नाम)
🦠 रोग का नाम: (पूरा नाम)
⚠️ गंभीरता: उच्च / मध्यम / कम
📉 नुकसान: (इलाज न करने पर कितना % नुकसान)

🔍 लक्षण:
• लक्षण १
• लक्षण २

💊 दवाइयां:
1. दवा का नाम — मात्रा (जैसे Mancozeb 75% WP — 2.5g प्रति लीटर पानी)
   कब डालें: हर 7 दिन में 3 हफ्ते

🌿 घरेलू उपाय: (आसान घरेलू उपाय)

🛠️ इलाज के कदम:
कदम १: आज करें
कदम २: 2-3 दिन में करें
कदम ३: साप्ताहिक करें

🛡️ रोकथाम: (अगले मौसम के लिए सलाह)

💪 प्रोत्साहन संदेश""",

        'en': """When farmer sends a crop photo always provide:
🌱 Crop: (crop name)
🦠 Disease: (full disease name + scientific name)
⚠️ Severity: High / Medium / Low
📉 Yield Loss: (% loss if untreated)

🔍 Symptoms:
• symptom 1
• symptom 2

💊 Medicines:
1. Medicine name — dosage (e.g. Mancozeb 75% WP — 2.5g per litre water)
   Frequency: Every 7 days for 3 weeks

2. Second option — dosage

🌿 Organic Remedy: (simple home remedy)

🛠️ Treatment Steps:
Step 1: Do today
Step 2: Do in 2-3 days
Step 3: Weekly action
Step 4: Long-term prevention

🛡️ Prevention: (next season tips)

💪 Encouraging message for the farmer"""
    }

    base = f"""You are FarmAI — an expert agricultural AI assistant for Indian farmers in Maharashtra.

LANGUAGE RULE: {lang_rules.get(lang, lang_rules['mr'])}

DISEASE FORMAT (follow exactly when photo is uploaded):
{disease_format.get(lang, disease_format['mr'])}

For general farming questions: give practical, simple answers with emojis.
For government schemes: explain PM-KISAN, Fasal Bima, KCC with eligibility and how to apply.
For weather/crop advice: suggest best crops for the season with reasons.
Always be warm, encouraging and speak like a helpful friend."""

    return base


@chatbot_bp.route('/')
def index():
    return render_template('chatbot.html')


@chatbot_bp.route('/chat', methods=['POST'])
def chat():
    data        = request.get_json()
    messages    = data.get('messages', [])
    image_data  = data.get('image_data')
    image_type  = data.get('image_type', 'image/jpeg')
    active_lang = data.get('active_lang', 'mr')

    if not messages:
        return {'success': False, 'message': 'No messages'}, 400

    system = build_system_prompt(active_lang)

    # Build groq messages — system first, then history
    groq_messages = [{'role': 'system', 'content': system}]

    # Add history except last message
    for msg in messages[:-1]:
        role    = msg.get('role', 'user')
        content = msg.get('content', '').strip()
        if role in ('user', 'assistant') and content:
            groq_messages.append({'role': role, 'content': content})

    # Last user message
    last_msg  = messages[-1]
    user_text = last_msg.get('content', '').strip()

    # Default prompt for image with no text
    if image_data and not user_text:
        prompts = {
            'mr': 'या पिकाच्या फोटोचे विश्लेषण करा. रोग ओळखा आणि संपूर्ण उपचार सांगा.',
            'hi': 'इस फसल की फोटो का विश्लेषण करें। रोग पहचानें और पूरा इलाज बताएं।',
            'en': 'Analyze this crop photo. Identify the disease and provide complete treatment with medicines and dosage.',
        }
        user_text = prompts.get(active_lang, prompts['mr'])

    if not user_text:
        user_text = 'Hello'

    # Build content — image + text or text only
    if image_data:
        content = [
            {
                'type':      'image_url',
                'image_url': {'url': f'data:{image_type};base64,{image_data}'}
            },
            {
                'type': 'text',
                'text': user_text
            }
        ]
        model = 'meta-llama/llama-4-scout-17b-16e-instruct'
    else:
        content = user_text
        model   = 'llama-3.3-70b-versatile'

    groq_messages.append({'role': 'user', 'content': content})

    def generate():
        try:
            client = Groq(api_key=current_app.config['GROQ_API_KEY'])
            stream = client.chat.completions.create(
                model       = model,
                messages    = groq_messages,
                max_tokens  = 2000,
                temperature = 0.2,
                stream      = True,
            )
            for chunk in stream:
                text = chunk.choices[0].delta.content or ''
                if text:
                    yield f"data: {json.dumps({'text': text})}\n\n"
            yield "data: [DONE]\n\n"

        except Exception as e:
            err_msgs = {
                'mr': f'माफ करा, त्रुटी आली: {str(e)}',
                'hi': f'माफ करें, त्रुटि हुई: {str(e)}',
                'en': f'Sorry, error occurred: {str(e)}',
            }
            yield f"data: {json.dumps({'error': err_msgs.get(active_lang, str(e))})}\n\n"

    return Response(
        stream_with_context(generate()),
        mimetype = 'text/event-stream',
        headers  = {'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no'}
    )
