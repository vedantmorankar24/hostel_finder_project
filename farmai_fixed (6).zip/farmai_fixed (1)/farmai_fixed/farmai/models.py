from extensions import db
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash


class User(db.Model):
    __tablename__ = 'users'

    id            = db.Column(db.Integer, primary_key=True)
    name          = db.Column(db.String(100), nullable=False)
    phone         = db.Column(db.String(15), unique=True, nullable=False)
    email         = db.Column(db.String(120), unique=True, nullable=True)
    password_hash = db.Column(db.String(256), nullable=False)
    state         = db.Column(db.String(50), default='Maharashtra')
    district      = db.Column(db.String(50), default='Nashik')
    land_size     = db.Column(db.String(20), default='small')   # small / medium / large
    primary_crop  = db.Column(db.String(50), default='Onion')
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)

    scans    = db.relationship('DiseaseScan', backref='user', lazy=True)
    searches = db.relationship('SchemeSearch', backref='user', lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return f'<User {self.name}>'


class DiseaseScan(db.Model):
    __tablename__ = 'disease_scans'

    id           = db.Column(db.Integer, primary_key=True)
    user_id      = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    image_path   = db.Column(db.String(255), nullable=False)
    crop_type    = db.Column(db.String(50))
    disease_name = db.Column(db.String(150))
    severity     = db.Column(db.String(20))
    confidence   = db.Column(db.Float)
    description  = db.Column(db.Text)
    solutions    = db.Column(db.JSON)        # stored as JSON array
    scanned_at   = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<DiseaseScan {self.disease_name}>'


class SchemeSearch(db.Model):
    __tablename__ = 'scheme_searches'

    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    state      = db.Column(db.String(50))
    land_size  = db.Column(db.String(20))
    crop       = db.Column(db.String(50))
    results    = db.Column(db.JSON)          # list of scheme dicts
    searched_at = db.Column(db.DateTime, default=datetime.utcnow)


class Scheme(db.Model):
    __tablename__ = 'schemes'

    id          = db.Column(db.Integer, primary_key=True)
    name        = db.Column(db.String(200), nullable=False)
    ministry    = db.Column(db.String(200))
    description = db.Column(db.Text)
    benefit     = db.Column(db.String(300))
    apply_url   = db.Column(db.String(300))
    tags        = db.Column(db.JSON)           # ['All Farmers', 'Direct Benefit']
    states      = db.Column(db.JSON)           # ['all'] or ['Maharashtra', 'UP']
    land_sizes  = db.Column(db.JSON)           # ['small', 'medium', 'large'] or ['all']
    crops       = db.Column(db.JSON)           # ['all'] or specific crops
    icon        = db.Column(db.String(10), default='💰')
    is_active   = db.Column(db.Boolean, default=True)

    def __repr__(self):
        return f'<Scheme {self.name}>'
