import os, json, base64, uuid
from flask import Blueprint, render_template, request, jsonify, session, current_app, redirect, url_for
from groq import Groq
from models import DiseaseScan
from extensions import db

disease_bp = Blueprint('disease', __name__)
ALLOWED = {'png', 'jpg', 'jpeg', 'webp'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED


@disease_bp.route('/')
def index():
    return redirect(url_for('chatbot.index') + '#disease')


@disease_bp.route('/analyze', methods=['POST'])
def analyze():
    if 'image' not in request.files:
        return jsonify({'success': False, 'message': 'No image uploaded'}), 400

    file      = request.files['image']
    crop_type     = request.form.get('crop_type', '')
    voice_context = request.form.get('voice_context', '')
    lang          = request.form.get('lang', 'en')  # 'mr', 'hi', or 'en'

    if not file or not allowed_file(file.filename):
        return jsonify({'success': False, 'message': 'Invalid file type. Use JPG or PNG.'}), 400

    # Save uploaded image
    upload_folder = current_app.config['UPLOAD_FOLDER']
    os.makedirs(upload_folder, exist_ok=True)
    ext      = file.filename.rsplit('.', 1)[1].lower()
    filename = f"{uuid.uuid4().hex}.{ext}"
    filepath = os.path.join(upload_folder, filename)
    file.save(filepath)

    # Read and base64-encode for Groq vision
    with open(filepath, 'rb') as f:
        image_data = base64.standard_b64encode(f.read()).decode('utf-8')
    media_type = 'image/jpeg' if ext == 'jpg' else f'image/{ext}'

    # Language instruction — written in target language so model cannot ignore it
    LANG_RULES = {
        'mr': """सूचना: खालील JSON मधील सर्व मजकूर (disease, description, symptoms, recovery_steps, medicines, organic_remedy, prevention_tips) संपूर्णपणे मराठी भाषेत लिहा. एकही शब्द इंग्रजीत नको. औषधांची नावे मराठीत उच्चारानुसार लिहा. IMPORTANT: Every single text value in the JSON must be in Marathi script only.""",
        'hi': """निर्देश: नीचे दिए गए JSON में सभी text values (disease, description, symptoms, recovery_steps, medicines, organic_remedy, prevention_tips) पूरी तरह हिंदी में लिखें। एक भी शब्द अंग्रेजी में नहीं। दवाइयों के नाम हिंदी में लिखें। IMPORTANT: Every single text value in the JSON must be in Hindi script only.""",
        'en': "Write all text values in English.",
    }
    lang_rule = LANG_RULES.get(lang, LANG_RULES['en'])

    prompt = f"""You are an expert agricultural plant pathologist and agronomist.
Analyze this crop image carefully and provide a complete disease diagnosis.
{("The crop is: " + crop_type) if crop_type else "First identify the crop type from the image."}
{("Farmer described the problem as: " + voice_context) if voice_context else ""}

{lang_rule}

Respond ONLY with valid JSON — no markdown, no extra text, no code fences:
{{
  "crop_detected": "Name of crop",
  "disease": "Full disease name or No Disease Detected",
  "scientific_name": "Scientific name of pathogen or empty string",
  "severity": "High|Medium|Low|None",
  "confidence": 92,
  "affected_parts": "leaves, stem, roots etc",
  "description": "2-3 sentences explaining the disease, how it spreads and damage it causes.",
  "symptoms": [
    "Visible symptom 1",
    "Visible symptom 2",
    "Visible symptom 3"
  ],
  "recovery_steps": [
    "Step 1: Immediate action today",
    "Step 2: Action within 2-3 days",
    "Step 3: Weekly follow-up",
    "Step 4: Long-term prevention"
  ],
  "medicines": [
    {{
      "name": "Medicine brand name",
      "type": "Fungicide|Pesticide|Bactericide|Organic",
      "dosage": "e.g. 2.5g per litre of water",
      "frequency": "e.g. Every 7 days for 3 weeks",
      "availability": "Available at local agri shops"
    }},
    {{
      "name": "Second medicine option",
      "type": "Fungicide|Pesticide|Bactericide|Organic",
      "dosage": "Exact dosage",
      "frequency": "How often to apply",
      "availability": "Available at Krishi Kendras"
    }}
  ],
  "organic_remedy": "One simple home remedy farmer can try immediately",
  "prevention_tips": [
    "Prevention tip 1",
    "Prevention tip 2",
    "Prevention tip 3"
  ],
  "estimated_yield_loss": "e.g. 30-50% if untreated",
  "urgency": "Treat immediately|Treat within 3 days|Monitor for 1 week|No action needed"
}}"""

    try:
        client   = Groq(api_key=current_app.config['GROQ_API_KEY'])
        response = client.chat.completions.create(
            model    = 'meta-llama/llama-4-scout-17b-16e-instruct',
            messages = [{
                'role':    'user',
                'content': [
                    {
                        'type':      'image_url',
                        'image_url': {'url': f'data:{media_type};base64,{image_data}'}
                    },
                    {
                        'type': 'text',
                        'text': prompt
                    }
                ]
            }],
            max_tokens  = 2000,
            temperature = 0.1,
        )
        raw    = response.choices[0].message.content.strip()
        raw    = raw.replace('```json', '').replace('```', '').strip()
        result = json.loads(raw)

    except json.JSONDecodeError:
        return jsonify({'success': False, 'message': 'AI returned invalid response. Please try again.'}), 500
    except Exception as e:
        return jsonify({'success': False, 'message': f'AI analysis failed: {str(e)}'}), 500

    # Save to DB if user is logged in
    if 'user_id' in session:
        scan = DiseaseScan(
            user_id      = session['user_id'],
            image_path   = f"uploads/{filename}",
            crop_type    = result.get('crop_detected', crop_type),
            disease_name = result.get('disease'),
            severity     = result.get('severity'),
            confidence   = result.get('confidence'),
            description  = result.get('description'),
            solutions    = result.get('recovery_steps', [])
        )
        db.session.add(scan)
        db.session.commit()
        result['scan_id']    = scan.id
        result['image_path'] = f"/static/uploads/{filename}"

    result['success'] = True
    return jsonify(result)


@disease_bp.route('/history')
def history():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Login required'}), 401
    scans = DiseaseScan.query.filter_by(user_id=session['user_id'])\
            .order_by(DiseaseScan.scanned_at.desc()).all()
    return jsonify({'success': True, 'scans': [
        {
            'id':           s.id,
            'crop_type':    s.crop_type,
            'disease_name': s.disease_name,
            'severity':     s.severity,
            'confidence':   s.confidence,
            'image_path':   f"/static/{s.image_path}",
            'scanned_at':   s.scanned_at.strftime('%d %b %Y, %I:%M %p')
        } for s in scans
    ]})
