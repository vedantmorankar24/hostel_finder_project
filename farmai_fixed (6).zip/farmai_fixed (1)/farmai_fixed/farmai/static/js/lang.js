// FarmAI — Language System (English + मराठी)
// Simple, reliable — no function overrides

const TRANSLATIONS = {
  en: {
    nav_disease:"🔬 Disease AI", nav_chat:"🤖 AI Chat", nav_crops:"Crop Advisor", nav_schemes:"Schemes", nav_prices:"Prices",
    nav_dashboard:"Dashboard", nav_logout:"Logout", nav_login:"Login", nav_register:"Register",
    footer_text:"🌾 FarmAI — Built for Indian Farmers",
    footer_sub:"Nashik, Maharashtra · Hackathon Project 2026",

    hero_badge:"Hackathon 2026 — Nashik",
    hero_title:"Smart AI Assistant<br>for Every <span class='hero-highlight'>Indian Farmer</span>",
    hero_sub:"Detect crop diseases instantly, get weather-based crop advice, and discover government schemes — all in one place, powered by AI.",
    hero_btn1:"🔬 Detect Disease Now", hero_btn2:"Create Free Account",
    stat1_label:"AI Features", stat2_label:"Diseases Detected", stat3_label:"Gov Schemes",
    features_heading:"Three Powerful Features",
    features_sub:"Everything a farmer needs, in one free platform",
    feat1_title:"Crop Disease AI",
    feat1_desc:"Upload a photo of any affected crop. Our AI identifies the disease, severity, and gives you step-by-step treatment in seconds.",
    feat1_cta:"Try Now →", feat2_title:"Weather Crop Advisor",
    feat2_desc:"Get AI-powered crop recommendations based on live weather data, season, and soil conditions specific to your location.",
    feat2_cta:"Get Advice →", feat3_title:"Government Schemes",
    feat3_desc:"Find all central and state government schemes you are eligible for — PM-KISAN, Fasal Bima, KCC and more.",
    feat3_cta:"Find Schemes →", how_heading:"How It Works",
    step1_title:"Upload Photo", step1_desc:"Take a photo of your crop leaf or plant",
    step2_title:"AI Analyzes", step2_desc:"Claude AI identifies disease instantly",
    step3_title:"Get Solutions", step3_desc:"Receive treatment steps and prevention tips",
    cta_heading:"Start Using FarmAI Today — It's Free",
    cta_sub:"No subscription. No hidden fees. Just smart AI for every farmer.",
    cta_btn:"Create Free Account →",

    disease_page_title:"🔬 Crop Disease Detection",
    disease_page_sub:"Upload a photo of your affected crop — AI will diagnose the disease and provide treatment",
    upload_card_title:"Upload Crop Photo",
    upload_h3:"Click or drag photo here",
    upload_p:"JPG, PNG, WEBP · Max 10MB<br>Take a close-up of affected leaves",
    crop_label:"Crop Type (optional)", crop_auto:"Auto-detect from image",
    analyze_btn:"🔬 Analyze with AI", analyzing_btn:"⏳ Analyzing...",
    result_treatment:"✅ Treatment Steps", crop_identified:"Crop identified:",
    recent_scans:"Recent Scans", login_hint:"Login to save your scan history.",
    no_scans:"No scans yet. Upload your first crop photo!",
    photo_tips:"📸 Photo Tips", scan_again:"🔬 Analyze Again",
    tip1:"Take close-up of affected leaf or stem",
    tip2:"Use natural daylight, avoid flash",
    tip3:"Show both healthy and affected parts",
    tip4:"Keep camera steady for clear focus",

    weather_page_title:"🌦️ Weather Crop Advisor",
    weather_page_sub:"Get AI-powered crop recommendations based on live weather in your city",
    select_location:"Select Your Location",
    get_recommend_btn:"🤖 Get AI Crop Recommendations",
    analyzing_weather:"⏳ Analyzing weather...",
    ai_analysis:"AI Analysis", recommended_crops:"🌱 Recommended Crops",
    risk_alert:"⚠️ Risk Alert:", weeks_tip:"💡 This Week's Tip:",
    rabi_crops:"🗓️ Rabi Season Crops",
    rabi_sub:"Best crops for Nashik region this season:",
    why_location:"📍 Why Location Matters",
    wl1:"Temperature affects germination rate",
    wl2:"Humidity impacts disease risk",
    wl3:"Rainfall decides irrigation need",
    wl4:"Wind affects pollination & spraying",
    humidity:"Humidity", rainfall:"Rainfall", wind:"Wind", season:"Season", rabi:"Rabi",
    match_word:"match",

    schemes_page_title:"📋 Government Schemes Finder",
    schemes_page_sub:"Find all central & state schemes you are eligible for — with direct apply links",
    farmer_profile:"Your Farmer Profile", state_label:"State", land_label:"Land Size",
    land_small:"Small — Less than 2 acres", land_medium:"Medium — 2 to 5 acres", land_large:"Large — More than 5 acres",
    crop_label2:"Primary Crop", find_btn:"📋 Find My Eligible Schemes", finding_btn:"⏳ Searching...",
    key_schemes:"🔑 Key Central Schemes", helplines:"📞 Helpline Numbers",
    apply_online:"Apply Online →", how_to_apply:"How to Apply",
    found_schemes:"✅ Found {count} schemes for {crop} farmer in {state}",
    csc_msg:"Visit nearest CSC centre or bank branch to apply.",

    welcome_back:"Welcome Back", login_sub:"Login to your FarmAI account",
    phone_label:"Mobile Number", password_label:"Password",
    login_btn:"Login →", no_account:"Don't have an account?", register_free:"Register free",
    create_account:"Create Free Account", reg_sub:"Join thousands of farmers using FarmAI",
    name_label:"Full Name", email_label:"Email (optional)", district_label:"District",
    register_btn:"Create Account →", already_reg:"Already registered?", login_here:"Login here",
    creating_acc:"Creating account...", logging_in:"Logging in...",

    phone_placeholder:"Mobile Number", password_placeholder:"Min 6 characters",
    district_placeholder:"Nashik",
    state_mh:"Maharashtra", state_up:"Uttar Pradesh", state_mp:"Madhya Pradesh",
    state_pb:"Punjab", state_gj:"Gujarat",
    crop_onion:"Onion", crop_tomato:"Tomato", crop_wheat:"Wheat",
    crop_rice:"Rice", crop_cotton:"Cotton", crop_sugarcane:"Sugarcane",
    feat4_title:"Mandi Prices", feat4_desc:"Get live mandi prices for 14 crops across Maharashtra markets. AI tells you when to sell and which mandi gives best price.", feat4_cta:"Check Prices →",
    how_sub:"3 simple steps — no technical knowledge needed",

    total_scans:"Total Scans", scheme_searches:"Scheme Searches",
    primary_crop:"Primary Crop", farm_size:"Farm Size", quick_actions:"Quick Actions",
    scan_new:"Scan New Crop", scan_new_sub:"Upload photo for disease detection",
    crop_advisor:"Crop Advisor", crop_adv_sub:"Today's weather recommendations",
    find_schemes:"Find Schemes", find_sch_sub:"Check your latest eligibility",
    recent_disease:"Recent Disease Scans",
    col_crop:"Crop", col_disease:"Disease", col_severity:"Severity",
    col_confidence:"Confidence", col_date:"Date",

    elig_name_label:"Your Name", age_label:"Age",
    age_young:"18–40 years", age_middle:"41–59 years", age_senior:"60+ years",
    category_label:"Category (optional)",
    cat_general:"General", cat_sc:"SC (Scheduled Caste)", cat_st:"ST (Scheduled Tribe)", cat_obc:"OBC",
    state_rj:"Rajasthan",
    crop_soybean:"Soybean", crop_maize:"Maize", crop_grapes:"Grapes",
    find_btn_modal:"✅ Find My Schemes",
  },

  mr: {
    nav_disease:"🔬 रोग AI", nav_chat:"🤖 AI गप्पा", nav_crops:"पीक सल्लागार", nav_schemes:"योजना", nav_prices:"मंडी भाव",
    nav_dashboard:"डॅशबोर्ड", nav_logout:"बाहेर पडा", nav_login:"लॉगिन", nav_register:"नोंदणी करा",
    footer_text:"🌾 FarmAI — भारतीय शेतकऱ्यांसाठी बनवले",
    footer_sub:"नाशिक, महाराष्ट्र · हॅकेथॉन प्रकल्प 2026",

    hero_badge:"हॅकेथॉन 2026 — नाशिक",
    hero_title:"प्रत्येक <span class='hero-highlight'>भारतीय शेतकऱ्यासाठी</span><br>स्मार्ट AI सहाय्यक",
    hero_sub:"पिकाचे रोग त्वरित ओळखा, हवामानावर आधारित पीक सल्ला मिळवा आणि सरकारी योजना शोधा — सर्व एकाच ठिकाणी.",
    hero_btn1:"🔬 रोग ओळखा आता", hero_btn2:"मोफत खाते तयार करा",
    stat1_label:"AI वैशिष्ट्ये", stat2_label:"रोग ओळखले", stat3_label:"सरकारी योजना",
    features_heading:"तीन शक्तिशाली वैशिष्ट्ये",
    features_sub:"शेतकऱ्याला लागणारे सर्वकाही, एका मोफत प्लॅटफॉर्मवर",
    feat1_title:"पीक रोग AI",
    feat1_desc:"कोणत्याही प्रभावित पिकाचा फोटो अपलोड करा. आमचे AI सेकंदात रोग, तीव्रता आणि उपाय सांगते.",
    feat1_cta:"आता वापरा →", feat2_title:"हवामान पीक सल्लागार",
    feat2_desc:"तुमच्या स्थानाच्या हवामानावर आधारित AI द्वारे सर्वोत्तम पिकांचा सल्ला मिळवा.",
    feat2_cta:"सल्ला मिळवा →", feat3_title:"सरकारी योजना",
    feat3_desc:"PM-KISAN, फसल बीमा, KCC आणि इतर — तुमच्यासाठी पात्र असलेल्या सर्व योजना शोधा.",
    feat3_cta:"योजना शोधा →", how_heading:"कसे वापरावे",
    step1_title:"फोटो अपलोड करा", step1_desc:"पिकाच्या पानाचा किंवा झाडाचा फोटो काढा",
    step2_title:"AI विश्लेषण", step2_desc:"Claude AI त्वरित रोग ओळखतो",
    step3_title:"उपाय मिळवा", step3_desc:"उपचार पायऱ्या आणि प्रतिबंध टिप्स मिळवा",
    cta_heading:"आजच FarmAI वापरणे सुरू करा — मोफत आहे",
    cta_sub:"कोणतीही सदस्यता नाही. कोणतेही लपलेले शुल्क नाही. प्रत्येक शेतकऱ्यासाठी स्मार्ट AI.",
    cta_btn:"मोफत खाते तयार करा →",

    disease_page_title:"🔬 पीक रोग ओळख",
    disease_page_sub:"प्रभावित पिकाचा फोटो अपलोड करा — AI रोगाचे निदान करेल आणि उपचार देईल",
    upload_card_title:"पिकाचा फोटो अपलोड करा",
    upload_h3:"येथे फोटो टाका",
    upload_p:"JPG, PNG, WEBP · जास्तीत जास्त 10MB<br>प्रभावित पानाचा जवळून फोटो काढा",
    crop_label:"पिकाचा प्रकार (ऐच्छिक)", crop_auto:"फोटोवरून आपोआप ओळखा",
    analyze_btn:"🔬 AI ने विश्लेषण करा", analyzing_btn:"⏳ विश्लेषण होत आहे...",
    result_treatment:"✅ उपचार पायऱ्या", crop_identified:"पीक ओळखले:",
    recent_scans:"अलीकडील स्कॅन", login_hint:"स्कॅन इतिहास जतन करण्यासाठी लॉगिन करा.",
    no_scans:"अजून स्कॅन नाही. पहिला फोटो अपलोड करा!",
    photo_tips:"📸 फोटो टिप्स", scan_again:"🔬 पुन्हा विश्लेषण करा",
    tip1:"प्रभावित पान किंवा खोडाचा जवळून फोटो काढा",
    tip2:"नैसर्गिक प्रकाश वापरा, फ्लॅश नको",
    tip3:"निरोगी आणि रोगग्रस्त दोन्ही भाग दाखवा",
    tip4:"स्पष्ट फोकससाठी कॅमेरा स्थिर ठेवा",

    weather_page_title:"🌦️ हवामान पीक सल्लागार",
    weather_page_sub:"तुमच्या शहरातील हवामानावर आधारित AI पीक शिफारसी मिळवा",
    select_location:"तुमचे स्थान निवडा",
    get_recommend_btn:"🤖 AI पीक शिफारसी मिळवा",
    analyzing_weather:"⏳ हवामान विश्लेषण होत आहे...",
    ai_analysis:"AI विश्लेषण", recommended_crops:"🌱 शिफारस केलेली पिके",
    risk_alert:"⚠️ धोक्याचा इशारा:", weeks_tip:"💡 या आठवड्याची टिप:",
    rabi_crops:"🗓️ रब्बी हंगाम पिके",
    rabi_sub:"या हंगामात नाशिक क्षेत्रासाठी सर्वोत्तम पिके:",
    why_location:"📍 स्थान का महत्त्वाचे आहे",
    wl1:"तापमान उगवण दरावर परिणाम करते",
    wl2:"आर्द्रता रोगाच्या जोखमीवर परिणाम करते",
    wl3:"पाऊस सिंचनाची गरज ठरवतो",
    wl4:"वारा परागीभवन आणि फवारणीवर परिणाम करतो",
    humidity:"आर्द्रता", rainfall:"पाऊस", wind:"वारा", season:"हंगाम", rabi:"रब्बी",
    match_word:"जुळणारे",

    schemes_page_title:"📋 सरकारी योजना शोधक",
    schemes_page_sub:"थेट अर्ज लिंकसह — तुमच्यासाठी पात्र असलेल्या सर्व केंद्र आणि राज्य योजना शोधा",
    farmer_profile:"तुमची शेतकरी प्रोफाइल", state_label:"राज्य", land_label:"जमीन आकार",
    land_small:"लहान — 2 एकरपेक्षा कमी", land_medium:"मध्यम — 2 ते 5 एकर", land_large:"मोठे — 5 एकरपेक्षा जास्त",
    crop_label2:"मुख्य पीक", find_btn:"📋 माझ्या पात्र योजना शोधा", finding_btn:"⏳ शोधत आहे...",
    key_schemes:"🔑 मुख्य केंद्रीय योजना", helplines:"📞 हेल्पलाइन नंबर",
    apply_online:"ऑनलाइन अर्ज करा →", how_to_apply:"अर्ज कसा करावा",
    found_schemes:"✅ {state} मध्ये {crop} शेतकऱ्यासाठी {count} योजना सापडल्या",
    csc_msg:"जवळच्या CSC केंद्र किंवा बँक शाखेत अर्ज करा.",

    welcome_back:"पुन्हा स्वागत आहे", login_sub:"तुमच्या FarmAI खात्यात लॉगिन करा",
    phone_label:"मोबाइल नंबर", password_label:"पासवर्ड",
    login_btn:"लॉगिन →", no_account:"खाते नाही?", register_free:"मोफत नोंदणी करा",
    create_account:"मोफत खाते तयार करा", reg_sub:"FarmAI वापरणाऱ्या हजारो शेतकऱ्यांमध्ये सामील व्हा",
    name_label:"पूर्ण नाव", email_label:"ईमेल (ऐच्छिक)", district_label:"जिल्हा",
    register_btn:"खाते तयार करा →", already_reg:"आधीच नोंदणी केली आहे?", login_here:"येथे लॉगिन करा",
    creating_acc:"खाते तयार होत आहे...", logging_in:"लॉगिन होत आहे...",

    phone_placeholder:"मोबईल नंबर ", password_placeholder:"किमान ६ अक्षरे",
    district_placeholder:"नाशिक",
    state_mh:"महाराष्ट्र", state_up:"उत्तर प्रदेश", state_mp:"मध्य प्रदेश",
    state_pb:"पंजाब", state_gj:"गुजरात",
    crop_onion:"कांदा", crop_tomato:"टोमॅटो", crop_wheat:"गहू",
    crop_rice:"तांदूळ", crop_cotton:"कापूस", crop_sugarcane:"ऊस",
    feat4_title:"मंडी भाव", feat4_desc:"महाराष्ट्रातील 14 पिकांचे थेट मंडी भाव मिळवा. AI सांगते कधी विकायचे आणि कोणती मंडी सर्वोत्तम भाव देते.", feat4_cta:"भाव तपासा →",
    how_sub:"३ सोपे पायरे — कोणतेही तांत्रिक ज्ञान नको",

    total_scans:"एकूण स्कॅन", scheme_searches:"योजना शोध",
    primary_crop:"मुख्य पीक", farm_size:"शेत आकार", quick_actions:"जलद कृती",
    scan_new:"नवीन पीक स्कॅन करा", scan_new_sub:"रोग ओळखण्यासाठी फोटो अपलोड करा",
    crop_advisor:"पीक सल्लागार", crop_adv_sub:"आजच्या हवामानाच्या शिफारसी",
    find_schemes:"योजना शोधा", find_sch_sub:"तुमची नवीनतम पात्रता तपासा",
    recent_disease:"अलीकडील रोग स्कॅन",
    col_crop:"पीक", col_disease:"रोग", col_severity:"तीव्रता",
    col_confidence:"आत्मविश्वास", col_date:"तारीख",

    elig_name_label:"तुमचे नाव", age_label:"वय",
    age_young:"१८–४० वर्षे", age_middle:"४१–५९ वर्षे", age_senior:"६०+ वर्षे",
    category_label:"प्रवर्ग (ऐच्छिक)",
    cat_general:"सामान्य", cat_sc:"SC (अनुसूचित जाती)", cat_st:"ST (अनुसूचित जमाती)", cat_obc:"OBC",
    state_rj:"राजस्थान",
    crop_soybean:"सोयाबीन", crop_maize:"मका", crop_grapes:"द्राक्ष",
    find_btn_modal:"✅ माझ्या योजना शोधा",
  }
};

// ── Core state ───────────────────────────────────────────
var currentLang = localStorage.getItem('farmai_lang') || 'en';

// ── Get translated string with optional variable substitution ──
function t(key, vars) {
  var str = (TRANSLATIONS[currentLang] && TRANSLATIONS[currentLang][key])
          || (TRANSLATIONS['en'] && TRANSLATIONS['en'][key])
          || key;
  if (vars) {
    str = str.replace(/\{(\w+)\}/g, function(_, k) { return vars[k] !== undefined ? vars[k] : ''; });
  }
  return str;
}

// ── Apply all translations to the page ──────────────────
function applyTranslations() {
  var lang = currentLang;

  // Translate all data-i18n elements
  document.querySelectorAll('[data-i18n]').forEach(function(el) {
    var key = el.getAttribute('data-i18n');
    var val = (TRANSLATIONS[lang] && TRANSLATIONS[lang][key]) || (TRANSLATIONS['en'] && TRANSLATIONS['en'][key]);
    if (val !== undefined) el.innerHTML = val;
  });

  // Translate placeholders
  document.querySelectorAll('[data-i18n-ph]').forEach(function(el) {
    var key = el.getAttribute('data-i18n-ph');
    var val = (TRANSLATIONS[lang] && TRANSLATIONS[lang][key]) || (TRANSLATIONS['en'] && TRANSLATIONS['en'][key]);
    if (val !== undefined) el.placeholder = val;
  });

  // Translate select options
  document.querySelectorAll('select [data-i18n]').forEach(function(el) {
    var key = el.getAttribute('data-i18n');
    var val = (TRANSLATIONS[lang] && TRANSLATIONS[lang][key]) || (TRANSLATIONS['en'] && TRANSLATIONS['en'][key]);
    if (val !== undefined) el.textContent = val;
  });

  // Update lang toggle buttons
  var label = lang === 'en' ? 'मराठी' : 'English';
  ['langToggleBtn', 'langToggleBtnMobile'].forEach(function(id) {
    var btn = document.getElementById(id);
    if (btn) btn.textContent = label;
  });

  // Update html lang attribute
  document.documentElement.lang = lang === 'mr' ? 'mr' : 'en';

  // Switch font for Marathi Devanagari script
  document.body.style.fontFamily = lang === 'mr'
    ? "'Noto Sans Devanagari', 'DM Sans', sans-serif"
    : "'DM Sans', sans-serif";
}

// ── Toggle between English and Marathi ──────────────────
function toggleLang() {
  currentLang = currentLang === 'en' ? 'mr' : 'en';
  localStorage.setItem('farmai_lang', currentLang);
  applyTranslations();
}

// ── Mobile menu ──────────────────────────────────────────
function toggleMenu() {
  var menu = document.getElementById('mobileMenu');
  if (menu) menu.classList.toggle('open');
}

// ── Auto-hide flash messages ─────────────────────────────
function initFlash() {
  document.querySelectorAll('.flash').forEach(function(el) {
    setTimeout(function() { el.style.display = 'none'; }, 4000);
  });
}

// ── Run on page load ─────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
  applyTranslations();
  initFlash();
});