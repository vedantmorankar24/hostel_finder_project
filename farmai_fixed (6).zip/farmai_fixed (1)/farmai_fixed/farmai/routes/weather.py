import requests, json
from flask import Blueprint, render_template, request, jsonify, current_app
from groq import Groq

weather_bp = Blueprint('weather', __name__)

CITY_FALLBACK = {
    'nashik':     {'temp':28,'humidity':68,'rainfall':12,'wind':14,'desc':'Partly Cloudy','icon':'⛅'},
    'pune':       {'temp':31,'humidity':55,'rainfall': 5,'wind':18,'desc':'Sunny',         'icon':'☀️'},
    'aurangabad': {'temp':33,'humidity':45,'rainfall': 2,'wind':20,'desc':'Hot & Dry',     'icon':'🌤️'},
    'nagpur':     {'temp':36,'humidity':38,'rainfall': 0,'wind':22,'desc':'Very Hot',       'icon':'☀️'},
    'kolhapur':   {'temp':26,'humidity':78,'rainfall':20,'wind':10,'desc':'Mild & Humid',  'icon':'🌦️'},
    'solapur':    {'temp':34,'humidity':42,'rainfall': 3,'wind':17,'desc':'Warm & Dry',    'icon':'🌤️'},
    'amravati':   {'temp':35,'humidity':40,'rainfall': 1,'wind':19,'desc':'Hot',            'icon':'☀️'},
    'jalgaon':    {'temp':36,'humidity':36,'rainfall': 1,'wind':21,'desc':'Very Hot',       'icon':'☀️'},
    'ahmednagar': {'temp':32,'humidity':48,'rainfall': 4,'wind':16,'desc':'Warm',           'icon':'🌤️'},
    'satara':     {'temp':27,'humidity':72,'rainfall':15,'wind':12,'desc':'Mild',           'icon':'⛅'},
}


def get_weather(city: str) -> dict:
    """Try live weather first, fall back to static data."""
    api_key = current_app.config.get('OPENWEATHER_API_KEY', '')
    if api_key and api_key != 'your-openweather-key-here':
        try:
            url  = f"https://api.openweathermap.org/data/2.5/weather?q={city},IN&appid={api_key}&units=metric"
            resp = requests.get(url, timeout=5)
            data = resp.json()
            if resp.status_code == 200:
                return {
                    'temp':     round(data['main']['temp']),
                    'humidity': data['main']['humidity'],
                    'rainfall': round(data.get('rain', {}).get('1h', 0), 1),
                    'wind':     round(data['wind']['speed'] * 3.6),
                    'desc':     data['weather'][0]['description'].title(),
                    'icon':     '🌦️', 'source': 'live'
                }
        except Exception:
            pass
    # Fallback — match city key or use Nashik defaults
    key = city.lower().strip()
    return {**CITY_FALLBACK.get(key, CITY_FALLBACK['nashik']), 'source': 'static'}


@weather_bp.route('/')
def index():
    return render_template('weather.html')


@weather_bp.route('/data')
def weather_data():
    city    = request.args.get('city', 'nashik').lower()
    weather = get_weather(city)
    return jsonify({'success': True, 'weather': weather, 'city': city.title()})


@weather_bp.route('/recommend', methods=['POST'])
def recommend():
    data       = request.get_json()
    location   = data.get('location', 'Nashik')
    loc_type   = data.get('loc_type', 'city')        # 'city' or 'village'
    crop_count = int(data.get('crop_count', 6))       # how many crops to suggest
    crop_count = max(4, min(crop_count, 15))           # clamp between 4–15
    lang       = data.get('lang', 'en')               # 'mr', 'hi', or 'en'

    # Get weather for nearest city (village → use as query)
    weather = get_weather(location)

    # Language instruction for AI
    LANG_RULES = {
        'mr': "IMPORTANT: Respond in Marathi (मराठी) language only. Write ALL text values — summary, crop names, reasons, profit, risk, tip — in Marathi. Do NOT use English for any text value.",
        'hi': "IMPORTANT: Respond in Hindi (हिंदी) language only. Write ALL text values in Hindi. Do NOT use English for any text value.",
        'en': "Respond in English.",
    }
    lang_rule = LANG_RULES.get(lang, LANG_RULES['en'])

    # Build prompt asking for exactly crop_count crops
    prompt = f"""You are an expert agricultural advisor for Maharashtra, India.
Location: {location} ({'Village' if loc_type == 'village' else 'City'}), Maharashtra
Current weather: Temperature {weather['temp']}°C, Humidity {weather['humidity']}%, Rainfall {weather['rainfall']}mm, Wind {weather['wind']}km/h, {weather['desc']}.
Season: Rabi (April 2026).

{lang_rule}

Provide crop recommendations for a farmer in {location}.
{"This is a village location, so consider local soil types, water availability and village market access." if loc_type == 'village' else ""}

Respond ONLY with valid JSON (no markdown, no code fences, no extra text):
{{
  "summary": "2-3 sentence weather and farming summary specific to {location}",
  "top_crops": [
    {{
      "name": "Crop name",
      "emoji": "🌱",
      "match": 95,
      "reason": "Why this crop is ideal for current weather and location (1-2 sentences)",
      "profit": "Estimated profit e.g. ₹40,000-60,000 per acre"
    }}
  ],
  "risk": "Main farming risk this season for {location} in one sentence",
  "tip": "One specific actionable tip for farmers in {location} this week"
}}

IMPORTANT: You must suggest exactly {crop_count} different crops in the top_crops array.
Include a mix of: vegetables, cereals, pulses, cash crops — whatever suits this weather best.
Order them from highest to lowest suitability match percentage.
Be specific to {location} Maharashtra region."""

    try:
        client   = Groq(api_key=current_app.config['GROQ_API_KEY'])
        response = client.chat.completions.create(
            model    = 'llama-3.3-70b-versatile',
            messages = [{'role': 'user', 'content': prompt}],
            max_tokens  = 2000,
            temperature = 0.4,
        )
        raw    = response.choices[0].message.content.strip()
        raw    = raw.replace('```json', '').replace('```', '').strip()
        result = json.loads(raw)
        result['weather'] = weather
        result['success'] = True
        return jsonify(result)

    except json.JSONDecodeError:
        return jsonify({'success': False, 'message': 'AI returned invalid response. Please try again.'}), 500
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500
