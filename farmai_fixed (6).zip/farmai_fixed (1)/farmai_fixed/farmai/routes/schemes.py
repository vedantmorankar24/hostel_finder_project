from flask import Blueprint, render_template, request, jsonify, session
from models import Scheme, SchemeSearch, User
from extensions import db

schemes_bp = Blueprint('schemes', __name__)

# ── Full schemes dataset ─────────────────────────────────────────────────────
SCHEMES_DATA = [
    # ── CENTRAL SCHEMES ──
    {
        'name': 'PM-KISAN Samman Nidhi',
        'name_mr': 'पीएम-किसान सन्मान निधी',
        'ministry': 'Ministry of Agriculture, Govt. of India',
        'ministry_mr': 'कृषी मंत्रालय, भारत सरकार',
        'description': 'Direct income support of ₹6,000 per year to all landholding farmer families paid in three equal installments of ₹2,000 directly to bank account.',
        'description_mr': 'सर्व जमीनधारक शेतकरी कुटुंबांना दरवर्षी ₹6,000 थेट बँक खात्यात — ₹2,000 च्या तीन समान हप्त्यांमध्ये.',
        'benefit': '₹6,000/year (₹2,000 × 3 installments)',
        'benefit_mr': '₹6,000/वर्ष (₹2,000 × 3 हप्ते)',
        'apply_url': 'https://pmkisan.gov.in',
        'tags': ['All Farmers', 'Direct Benefit', 'Central Scheme'],
        'states': ['all'], 'land_sizes': ['all'], 'crops': ['all'],
        'icon': '💰', 'category': 'Income Support',
        'eligibility': 'All landholding farmer families',
        'documents': 'Aadhaar, Land records, Bank passbook',
        'helpline': '155261',
    },
    {
        'name': 'PM Fasal Bima Yojana (PMFBY)',
        'name_mr': 'पीएम फसल बीमा योजना (PMFBY)',
        'ministry': 'Ministry of Agriculture, Govt. of India',
        'ministry_mr': 'कृषी मंत्रालय, भारत सरकार',
        'description': 'Comprehensive crop insurance that protects farmers against financial losses due to crop failure from natural calamities, pests, and diseases. Premium is just 1.5–2% for farmers.',
        'description_mr': 'नैसर्गिक आपत्ती, कीड आणि रोगांमुळे पीक नुकसान झाल्यास शेतकऱ्यांना संपूर्ण भरपाई. शेतकऱ्यांसाठी प्रीमियम फक्त 1.5–2%.',
        'benefit': 'Full crop loss compensation | Premium only 1.5–2%',
        'benefit_mr': 'संपूर्ण पीक नुकसान भरपाई | प्रीमियम फक्त 1.5–2%',
        'apply_url': 'https://pmfby.gov.in',
        'tags': ['Crop Insurance', 'Risk Protection', 'Central Scheme'],
        'states': ['all'], 'land_sizes': ['all'], 'crops': ['all'],
        'icon': '🛡️', 'category': 'Insurance',
        'eligibility': 'All farmers growing notified crops',
        'documents': 'Aadhaar, Land records, Bank passbook, Sowing certificate',
        'helpline': '1800-200-7710',
    },
    {
        'name': 'Kisan Credit Card (KCC)',
        'name_mr': 'किसान क्रेडिट कार्ड (KCC)',
        'ministry': 'NABARD / All Nationalized Banks',
        'ministry_mr': 'NABARD / सर्व राष्ट्रीयकृत बँका',
        'description': 'Provides farmers with timely and flexible credit for seeds, fertilizers, pesticides, farm equipment and post-harvest needs at heavily subsidized interest rates.',
        'description_mr': 'बियाणे, खते, कीटकनाशके, शेती उपकरणे आणि काढणीनंतरच्या गरजांसाठी अत्यंत कमी व्याजदरात वेळेवर कर्ज.',
        'benefit': 'Credit up to ₹3 lakh at just 4% interest per year',
        'benefit_mr': 'फक्त 4% व्याजदरात ₹3 लाखांपर्यंत कर्ज',
        'apply_url': '',
        'tags': ['Easy Credit', 'Low Interest', 'Central Scheme'],
        'states': ['all'], 'land_sizes': ['all'], 'crops': ['all'],
        'icon': '🏦', 'category': 'Credit & Loans',
        'eligibility': 'All farmers, sharecroppers, and tenant farmers',
        'documents': 'Aadhaar, Land records or lease agreement, Passport photo',
        'helpline': '1800-22-0088',
    },
    {
        'name': 'PM Kisan Mandhan Yojana',
        'name_mr': 'पीएम किसान मानधन योजना',
        'ministry': 'Ministry of Agriculture, Govt. of India',
        'ministry_mr': 'कृषी मंत्रालय, भारत सरकार',
        'description': 'Old age pension scheme for small and marginal farmers. Farmers aged 18–40 contribute ₹55–₹200/month and receive guaranteed ₹3,000/month after age 60.',
        'description_mr': 'लहान व सीमांत शेतकऱ्यांसाठी वृद्धापकाळ निवृत्तीवेतन योजना. 18–40 वयाचे शेतकरी ₹55–₹200/महिना योगदान देतात आणि वयाच्या 60 नंतर ₹3,000/महिना मिळतो.',
        'benefit': '₹3,000/month guaranteed pension after age 60',
        'benefit_mr': 'वयाच्या 60 नंतर ₹3,000/महिना हमी निवृत्तीवेतन',
        'apply_url': 'https://maandhan.in',
        'tags': ['Pension', 'Long Term', 'Small Farmers'],
        'states': ['all'], 'land_sizes': ['small', 'medium'], 'crops': ['all'],
        'icon': '👴', 'category': 'Pension',
        'eligibility': 'Small & marginal farmers aged 18–40 years',
        'documents': 'Aadhaar, Bank passbook, Land records',
        'helpline': '1800-267-6888',
    },
    {
        'name': 'Soil Health Card Scheme',
        'name_mr': 'माती आरोग्य कार्ड योजना',
        'ministry': 'Ministry of Agriculture, Govt. of India',
        'ministry_mr': 'कृषी मंत्रालय, भारत सरकार',
        'description': 'Free soil testing and a personalized Soil Health Card for every farmer showing nutrient status of soil and crop-wise fertilizer recommendations to improve productivity.',
        'description_mr': 'प्रत्येक शेतकऱ्यासाठी मोफत माती परीक्षण आणि वैयक्तिक माती आरोग्य कार्ड — मातीतील पोषक तत्त्वांची स्थिती आणि पीकनिहाय खत शिफारसी.',
        'benefit': 'Free soil testing + personalized fertilizer advice card',
        'benefit_mr': 'मोफत माती परीक्षण + वैयक्तिक खत सल्ला कार्ड',
        'apply_url': 'https://soilhealth.dac.gov.in',
        'tags': ['Free Service', 'Soil Health', 'All Farmers'],
        'states': ['all'], 'land_sizes': ['all'], 'crops': ['all'],
        'icon': '🌍', 'category': 'Soil & Input',
        'eligibility': 'All farmers — no income limit',
        'documents': 'Aadhaar, Land records',
        'helpline': '1800-180-1551',
    },
    {
        'name': 'National Horticulture Mission (NHM)',
        'name_mr': 'राष्ट्रीय फलोत्पादन अभियान (NHM)',
        'ministry': 'Ministry of Agriculture, Govt. of India',
        'ministry_mr': 'कृषी मंत्रालय, भारत सरकार',
        'description': 'Promotes horticulture crops like vegetables, fruits, flowers, and spices through area expansion, modernization, storage infrastructure and technology adoption with 40–50% subsidy.',
        'description_mr': 'भाजीपाला, फळे, फुले आणि मसाल्यांच्या पिकांना 40–50% अनुदानासह क्षेत्र विस्तार, आधुनिकीकरण आणि साठवण पायाभूत सुविधांद्वारे प्रोत्साहन.',
        'benefit': '40–50% subsidy on horticulture inputs and infrastructure',
        'benefit_mr': 'फलोत्पादन निविष्ठा आणि पायाभूत सुविधांवर 40–50% अनुदान',
        'apply_url': 'https://nhb.gov.in',
        'tags': ['Horticulture', 'Subsidy', 'Vegetable Farmers'],
        'states': ['all'], 'land_sizes': ['all'],
        'crops': ['Onion', 'Tomato', 'Grapes', 'Pomegranate', 'Banana'],
        'icon': '🥬', 'category': 'Subsidy',
        'eligibility': 'Farmers growing horticulture crops',
        'documents': 'Aadhaar, Land records, Bank passbook',
        'helpline': '011-23382640',
    },
    {
        'name': 'PM Krishi Sinchai Yojana (PMKSY)',
        'name_mr': 'पीएम कृषी सिंचाई योजना (PMKSY)',
        'ministry': 'Ministry of Jal Shakti, Govt. of India',
        'ministry_mr': 'जलशक्ती मंत्रालय, भारत सरकार',
        'description': 'Har Khet Ko Pani — provides assured irrigation to every farm. Subsidizes drip and sprinkler irrigation systems by up to 55% for small farmers and 45% for others.',
        'description_mr': 'हर खेत को पानी — प्रत्येक शेताला सिंचन. लहान शेतकऱ्यांसाठी ठिबक व तुषार सिंचन प्रणालीवर 55% अनुदान.',
        'benefit': '55% subsidy on drip/sprinkler irrigation systems',
        'benefit_mr': 'ठिबक/तुषार सिंचन प्रणालीवर 55% अनुदान',
        'apply_url': 'https://pmksy.gov.in',
        'tags': ['Irrigation', 'Water', 'Subsidy'],
        'states': ['all'], 'land_sizes': ['all'], 'crops': ['all'],
        'icon': '💧', 'category': 'Irrigation',
        'eligibility': 'All farmers with agricultural land',
        'documents': 'Aadhaar, Land records, Bank passbook',
        'helpline': '1800-180-1551',
    },
    {
        'name': 'National Food Security Mission (NFSM)',
        'name_mr': 'राष्ट्रीय अन्न सुरक्षा अभियान (NFSM)',
        'ministry': 'Ministry of Agriculture, Govt. of India',
        'ministry_mr': 'कृषी मंत्रालय, भारत सरकार',
        'description': 'Increases production of rice, wheat, pulses, and coarse cereals through area expansion and productivity enhancement. Provides free quality seeds and fertilizer demonstrations.',
        'description_mr': 'तांदूळ, गहू, कडधान्ये आणि भरड धान्यांचे उत्पादन वाढवण्यासाठी मोफत दर्जेदार बियाणे, खते आणि शेती यंत्रसामग्रीवर अनुदान.',
        'benefit': 'Free quality seeds + fertilizer + farm machinery subsidies',
        'benefit_mr': 'मोफत दर्जेदार बियाणे + खते + शेती यंत्रसामग्री अनुदान',
        'apply_url': 'https://nfsm.gov.in',
        'tags': ['Food Crops', 'Seeds', 'Free Service'],
        'states': ['all'], 'land_sizes': ['all'],
        'crops': ['Wheat', 'Rice', 'Maize', 'Soybean'],
        'icon': '🌾', 'category': 'Crop Production',
        'eligibility': 'Farmers growing food crops — especially small/marginal',
        'documents': 'Aadhaar, Land records',
        'helpline': '011-23382557',
    },
    {
        'name': 'Agriculture Infrastructure Fund (AIF)',
        'name_mr': 'कृषी पायाभूत सुविधा निधी (AIF)',
        'ministry': 'Ministry of Agriculture, Govt. of India',
        'ministry_mr': 'कृषी मंत्रालय, भारत सरकार',
        'description': 'Medium to long term debt financing facility for investment in agriculture infrastructure like cold storage, warehouses, sorting/grading units, and processing plants.',
        'description_mr': 'शीतगृह, गोदाम, वर्गीकरण/श्रेणीकरण युनिट आणि प्रक्रिया प्रकल्पांसाठी मध्यम ते दीर्घकालीन कर्ज सुविधा.',
        'benefit': 'Loan up to ₹2 crore with 3% interest subsidy for 7 years',
        'benefit_mr': '7 वर्षांसाठी 3% व्याज अनुदानासह ₹2 कोटीपर्यंत कर्ज',
        'apply_url': 'https://agriinfra.dac.gov.in',
        'tags': ['Infrastructure', 'Cold Storage', 'Loan'],
        'states': ['all'], 'land_sizes': ['medium', 'large'], 'crops': ['all'],
        'icon': '🏭', 'category': 'Infrastructure',
        'eligibility': 'Farmers, FPOs, cooperatives, agri-entrepreneurs',
        'documents': 'Aadhaar, Land records, Project report, Bank statement',
        'helpline': '1800-3000-2018',
    },
    {
        'name': 'PM Formalisation of Micro Food Enterprises (PMFME)',
        'name_mr': 'पीएम सूक्ष्म अन्न प्रक्रिया उद्योग औपचारिकीकरण (PMFME)',
        'ministry': 'Ministry of Food Processing, Govt. of India',
        'ministry_mr': 'अन्न प्रक्रिया मंत्रालय, भारत सरकार',
        'description': 'Helps farmers and small food businesses set up or upgrade micro food processing enterprises with 35% credit-linked subsidy up to ₹10 lakh.',
        'description_mr': 'शेतकरी आणि लहान अन्न व्यवसायांना सूक्ष्म अन्न प्रक्रिया उद्योग उभारण्यासाठी ₹10 लाखांपर्यंत 35% कर्जसंलग्न अनुदान.',
        'benefit': '35% subsidy up to ₹10 lakh for food processing units',
        'benefit_mr': 'अन्न प्रक्रिया युनिटसाठी ₹10 लाखांपर्यंत 35% अनुदान',
        'apply_url': 'https://pmfme.mofpi.gov.in',
        'tags': ['Food Processing', 'Subsidy', 'Entrepreneurship'],
        'states': ['all'], 'land_sizes': ['all'], 'crops': ['all'],
        'icon': '🏪', 'category': 'Food Processing',
        'eligibility': 'Individual farmers and micro food processing units',
        'documents': 'Aadhaar, Business plan, Land records or rent agreement',
        'helpline': '011-26406557',
    },

    # ── MAHARASHTRA STATE SCHEMES ──
    {
        'name': 'Maharashtra Shetkari Sanman Yojana',
        'name_mr': 'महाराष्ट्र शेतकरी सन्मान योजना',
        'ministry': 'Maharashtra State Government',
        'ministry_mr': 'महाराष्ट्र राज्य सरकार',
        'description': 'State income support scheme providing financial assistance and input subsidies to registered Maharashtra farmers to supplement central PM-KISAN benefits.',
        'description_mr': 'नोंदणीकृत महाराष्ट्र शेतकऱ्यांना PM-KISAN व्यतिरिक्त आर्थिक सहाय्य आणि निविष्ठा अनुदान देणारी राज्य योजना.',
        'benefit': '₹12,000/year + fertilizer subsidy + free soil testing',
        'benefit_mr': '₹12,000/वर्ष + खत अनुदान + मोफत माती परीक्षण',
        'apply_url': '',
        'tags': ['Maharashtra Only', 'State Scheme', 'Income Support'],
        'states': ['Maharashtra'], 'land_sizes': ['all'], 'crops': ['all'],
        'icon': '🌱', 'category': 'Income Support',
        'eligibility': 'Registered Maharashtra farmers',
        'documents': 'Aadhaar, 7/12 Utara (land record), Bank passbook',
        'helpline': '1800-233-4000',
    },
    {
        'name': 'Magel Tyala Shet Tale (Farm Pond Scheme)',
        'name_mr': 'मागेल त्याला शेत तळे योजना',
        'ministry': 'Maharashtra Agriculture Department',
        'ministry_mr': 'महाराष्ट्र कृषी विभाग',
        'description': 'Maharashtra government provides subsidy for constructing farm ponds (shettale) to store rainwater for irrigation during dry spells, helping reduce dependency on groundwater.',
        'description_mr': 'कोरड्या काळात सिंचनासाठी पावसाचे पाणी साठवण्यासाठी शेत तळे बांधण्यावर महाराष्ट्र सरकार अनुदान देते.',
        'benefit': '100% subsidy for farm pond construction up to ₹75,000',
        'benefit_mr': 'शेत तळे बांधकामासाठी ₹75,000 पर्यंत 100% अनुदान',
        'apply_url': '',
        'tags': ['Maharashtra', 'Water Storage', 'Irrigation'],
        'states': ['Maharashtra'], 'land_sizes': ['all'], 'crops': ['all'],
        'icon': '🏞️', 'category': 'Irrigation',
        'eligibility': 'All Maharashtra farmers with minimum 0.4 hectare land',
        'documents': 'Aadhaar, 7/12 Utara, Satbara, Bank passbook',
        'helpline': '1800-233-4000',
    },
    {
        'name': 'Dr. Babasaheb Ambedkar Krishi Swavalamban Yojana',
        'name_mr': 'डॉ. बाबासाहेब आंबेडकर कृषी स्वावलंबन योजना',
        'ministry': 'Maharashtra Agriculture Department',
        'ministry_mr': 'महाराष्ट्र कृषी विभाग',
        'description': 'Special scheme for SC/ST farmers in Maharashtra providing financial assistance for farm ponds, drip irrigation, seed purchase, and agricultural equipment.',
        'description_mr': 'महाराष्ट्रातील SC/ST शेतकऱ्यांसाठी शेत तळे, ठिबक सिंचन, बियाणे खरेदी आणि शेती उपकरणांसाठी आर्थिक सहाय्य.',
        'benefit': 'Up to ₹2.5 lakh subsidy for farm development',
        'benefit_mr': 'शेत विकासासाठी ₹2.5 लाखांपर्यंत अनुदान',
        'apply_url': '',
        'tags': ['SC/ST Farmers', 'Maharashtra', 'Special Category'],
        'states': ['Maharashtra'], 'land_sizes': ['small', 'medium'], 'crops': ['all'],
        'icon': '🤝', 'category': 'Special Category',
        'eligibility': 'SC/ST farmers in Maharashtra',
        'documents': 'Aadhaar, Caste certificate, 7/12 Utara, Bank passbook',
        'helpline': '1800-233-4000',
    },
    {
        'name': 'Mukhyamantri Saur Krishi Pump Yojana',
        'name_mr': 'मुख्यमंत्री सौर कृषी पंप योजना',
        'ministry': 'Maharashtra Energy Department',
        'ministry_mr': 'महाराष्ट्र ऊर्जा विभाग',
        'description': 'Free solar-powered agricultural water pumps for farmers who do not have electricity connection on their farm. Reduces electricity cost to zero for irrigation.',
        'description_mr': 'शेतावर वीज जोडणी नसलेल्या शेतकऱ्यांना मोफत सौरऊर्जा कृषी पंप. सिंचनाचा वीज खर्च शून्यावर येतो.',
        'benefit': 'Free solar pump (3HP or 5HP) worth ₹2–3 lakh',
        'benefit_mr': 'मोफत सौर पंप (3HP किंवा 5HP) — किंमत ₹2–3 लाख',
        'apply_url': 'https://www.mahadiscom.in',
        'tags': ['Solar Energy', 'Free Pump', 'Maharashtra'],
        'states': ['Maharashtra'], 'land_sizes': ['all'], 'crops': ['all'],
        'icon': '☀️', 'category': 'Energy',
        'eligibility': 'Maharashtra farmers without existing electricity connection',
        'documents': 'Aadhaar, 7/12 Utara, Bank passbook, No electricity certificate',
        'helpline': '1800-200-3435',
    },
    {
        'name': 'Nanaji Deshmukh Krishi Sanjivani Project',
        'name_mr': 'नानाजी देशमुख कृषी संजीवनी प्रकल्प',
        'ministry': 'Maharashtra Agriculture Department',
        'ministry_mr': 'महाराष्ट्र कृषी विभाग',
        'description': 'Climate resilient agriculture project for drought-prone districts of Maharashtra. Promotes farm ponds, drip irrigation, crop diversification and farmer capacity building.',
        'description_mr': 'महाराष्ट्रातील दुष्काळप्रवण जिल्ह्यांसाठी हवामान-सहनशील शेती प्रकल्प. शेत तळे, ठिबक सिंचन, पीक विविधीकरण आणि शेतकरी क्षमता बांधणी.',
        'benefit': 'Multiple subsidies + free training + ₹25,000 per hectare support',
        'benefit_mr': 'अनेक अनुदाने + मोफत प्रशिक्षण + ₹25,000 प्रति हेक्टर सहाय्य',
        'apply_url': '',
        'tags': ['Drought Area', 'Maharashtra', 'Climate Resilient'],
        'states': ['Maharashtra'], 'land_sizes': ['small', 'medium'],
        'crops': ['all'],
        'icon': '🌊', 'category': 'Climate Support',
        'eligibility': 'Farmers in 15 drought-prone Maharashtra districts',
        'documents': 'Aadhaar, 7/12 Utara, Bank passbook',
        'helpline': '020-26123648',
    },

    # ── OTHER STATE SCHEMES ──
    {
        'name': 'Punjab Kisan Karj Mafi Yojana',
        'name_mr': 'पंजाब किसान कर्ज माफी योजना',
        'ministry': 'Punjab State Government',
        'ministry_mr': 'पंजाब राज्य सरकार',
        'description': 'Debt waiver scheme for small and marginal farmers of Punjab, providing relief from agricultural loans up to ₹2 lakh taken from cooperative banks.',
        'description_mr': 'पंजाबच्या लहान व सीमांत शेतकऱ्यांसाठी सहकारी बँकांकडून घेतलेल्या ₹2 लाखांपर्यंतच्या कृषी कर्जाची माफी.',
        'benefit': 'Loan waiver up to ₹2 lakh',
        'benefit_mr': '₹2 लाखांपर्यंत कर्जमाफी',
        'apply_url': '',
        'tags': ['Punjab Only', 'Loan Waiver', 'State Scheme'],
        'states': ['Punjab'], 'land_sizes': ['small', 'medium'], 'crops': ['all'],
        'icon': '🏦', 'category': 'Loan Waiver',
        'eligibility': 'Small & marginal Punjab farmers with cooperative bank loans',
        'documents': 'Aadhaar, Land records, Loan documents',
        'helpline': '0172-2970978',
    },
    {
        'name': 'Gujarat Kisan Suryodaya Yojana',
        'name_mr': 'गुजरात किसान सूर्योदय योजना',
        'ministry': 'Gujarat State Government',
        'ministry_mr': 'गुजरात राज्य सरकार',
        'description': 'Provides daytime electricity supply (5 AM to 9 PM) to agricultural consumers in Gujarat so farmers can operate pumps during daylight for irrigation.',
        'description_mr': 'गुजरातमधील कृषी ग्राहकांना दिवसा वीज पुरवठा (सकाळी 5 ते रात्री 9) — शेतकरी दिवसा पंप चालवू शकतात.',
        'benefit': 'Daytime electricity for irrigation — reduces diesel cost',
        'benefit_mr': 'सिंचनासाठी दिवसा वीज — डिझेल खर्च कमी होतो',
        'apply_url': '',
        'tags': ['Gujarat Only', 'Electricity', 'Irrigation'],
        'states': ['Gujarat'], 'land_sizes': ['all'], 'crops': ['all'],
        'icon': '⚡', 'category': 'Energy',
        'eligibility': 'All agricultural electricity consumers in Gujarat',
        'documents': 'Aadhaar, Electricity connection number, Land records',
        'helpline': '1800-233-3003',
    },
    {
        'name': 'UP Kisan Uday Yojana',
        'name_mr': 'UP किसान उदय योजना',
        'ministry': 'Uttar Pradesh State Government',
        'ministry_mr': 'उत्तर प्रदेश राज्य सरकार',
        'description': 'Provides free solar pumps to farmers in Uttar Pradesh to reduce irrigation costs. Covers 5–7.5 HP solar pumps for farm irrigation needs.',
        'description_mr': 'उत्तर प्रदेशातील शेतकऱ्यांना सिंचन खर्च कमी करण्यासाठी मोफत सौर पंप. शेती सिंचनासाठी 5–7.5 HP सौर पंप.',
        'benefit': 'Free 5–7.5 HP solar irrigation pump',
        'benefit_mr': 'मोफत 5–7.5 HP सौर सिंचन पंप',
        'apply_url': '',
        'tags': ['UP Only', 'Solar Pump', 'Free'],
        'states': ['Uttar Pradesh'], 'land_sizes': ['small', 'medium'], 'crops': ['all'],
        'icon': '🔆', 'category': 'Energy',
        'eligibility': 'Small & marginal UP farmers without pump connection',
        'documents': 'Aadhaar, Khasra/Khatauni, Bank passbook',
        'helpline': '1800-180-5000',
    },
    {
        'name': 'Rajasthan Mukhyamantri Kisan Mitra Urja Yojana',
        'name_mr': 'राजस्थान मुख्यमंत्री किसान मित्र ऊर्जा योजना',
        'ministry': 'Rajasthan State Government',
        'ministry_mr': 'राजस्थान राज्य सरकार',
        'description': 'Provides ₹1,000/month energy subsidy to metered agricultural consumers in Rajasthan to reduce electricity bills for irrigation pump operation.',
        'description_mr': 'राजस्थानमधील मीटर असलेल्या कृषी ग्राहकांना सिंचन पंपाचे वीज बिल कमी करण्यासाठी ₹1,000/महिना ऊर्जा अनुदान.',
        'benefit': 'Up to ₹12,000/year electricity subsidy',
        'benefit_mr': 'वर्षाला ₹12,000 पर्यंत वीज अनुदान',
        'apply_url': '',
        'tags': ['Rajasthan Only', 'Electricity Subsidy', 'State Scheme'],
        'states': ['Rajasthan'], 'land_sizes': ['small', 'medium'], 'crops': ['all'],
        'icon': '💡', 'category': 'Energy',
        'eligibility': 'Metered agricultural consumers in Rajasthan',
        'documents': 'Aadhaar, Electricity bill, Land records',
        'helpline': '1800-180-6127',
    },
    {
        'name': 'MP Mukhyamantri Kisan Kalyan Yojana',
        'name_mr': 'MP मुख्यमंत्री किसान कल्याण योजना',
        'ministry': 'Madhya Pradesh State Government',
        'ministry_mr': 'मध्य प्रदेश राज्य सरकार',
        'description': 'Additional ₹4,000/year income support for MP farmers over and above PM-KISAN, paid in two installments of ₹2,000 directly to farmer bank accounts.',
        'description_mr': 'PM-KISAN व्यतिरिक्त MP शेतकऱ्यांना ₹4,000/वर्ष अतिरिक्त उत्पन्न सहाय्य — ₹2,000 च्या दोन हप्त्यांमध्ये थेट बँक खात्यात.',
        'benefit': '₹4,000/year additional income support',
        'benefit_mr': '₹4,000/वर्ष अतिरिक्त उत्पन्न सहाय्य',
        'apply_url': '',
        'tags': ['MP Only', 'Income Support', 'State Scheme'],
        'states': ['Madhya Pradesh'], 'land_sizes': ['all'], 'crops': ['all'],
        'icon': '💵', 'category': 'Income Support',
        'eligibility': 'MP farmers already registered under PM-KISAN',
        'documents': 'Aadhaar, PM-KISAN registration number, Bank passbook',
        'helpline': '0755-2550495',
    },
]


def seed_schemes():
    if Scheme.query.count() == 0:
        for s in SCHEMES_DATA:
            scheme = Scheme(
                name        = s['name'],
                ministry    = s['ministry'],
                description = s['description'],
                benefit     = s['benefit'],
                apply_url   = s.get('apply_url', ''),
                tags        = s.get('tags', []),
                states      = s.get('states', ['all']),
                land_sizes  = s.get('land_sizes', ['all']),
                crops       = s.get('crops', ['all']),
                icon        = s.get('icon', '📋'),
            )
            db.session.add(scheme)
        db.session.commit()
        print(f"✅ Seeded {len(SCHEMES_DATA)} schemes")


@schemes_bp.route('/')
def index():
    # Pass all schemes directly to template for display
    all_schemes = SCHEMES_DATA  # Use static data so no DB needed for browsing
    categories  = sorted(set(s.get('category','Other') for s in all_schemes))
    states_list = sorted(set(
        st for s in all_schemes for st in s['states'] if st != 'all'
    ))

    # If user is logged in, get their profile for pre-fill
    user = None
    if 'user_id' in session:
        user = User.query.get(session['user_id'])

    return render_template('schemes.html',
        all_schemes = all_schemes,
        categories  = categories,
        states_list = states_list,
        user        = user,
        total       = len(all_schemes)
    )


@schemes_bp.route('/search', methods=['POST'])
def search():
    data      = request.get_json()
    state     = data.get('state', '')
    land_size = data.get('land_size', '')
    crop      = data.get('crop', '')
    category  = data.get('category', '')

    matched = []
    for s in SCHEMES_DATA:
        state_ok    = not state    or 'all' in s['states']    or state    in s['states']
        land_ok     = not land_size or 'all' in s['land_sizes'] or land_size in s['land_sizes']
        crop_ok     = not crop     or 'all' in s['crops']     or crop     in s['crops']
        category_ok = not category or s.get('category') == category
        if state_ok and land_ok and crop_ok and category_ok:
            matched.append({**s, 'id': SCHEMES_DATA.index(s) + 1})

    # Save search log if logged in
    if 'user_id' in session:
        try:
            log = SchemeSearch(
                user_id   = session['user_id'],
                state     = state, land_size = land_size,
                crop      = crop,  results   = matched
            )
            db.session.add(log)
            db.session.commit()
        except Exception:
            pass

    return jsonify({'success': True, 'count': len(matched), 'schemes': matched})