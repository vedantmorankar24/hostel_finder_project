import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'farmai-secret-key-change-in-production')

    # MySQL Database
    MYSQL_HOST     = os.environ.get('MYSQL_HOST', 'localhost')
    MYSQL_PORT     = int(os.environ.get('MYSQL_PORT', 3306))
    MYSQL_USER     = os.environ.get('MYSQL_USER', 'root')
    MYSQL_PASSWORD = os.environ.get('MYSQL_PASSWORD', 'vedant')
    MYSQL_DB       = os.environ.get('MYSQL_DB', 'farmai_db')

    SQLALCHEMY_DATABASE_URI = (
        f"mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}"
        f"@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DB}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Groq API — FREE forever — get key at https://console.groq.com
    GROQ_API_KEY = os.environ.get('GROQ_API_KEY', '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')

    # OpenWeatherMap API (optional)
    OPENWEATHER_API_KEY = os.environ.get('OPENWEATHER_API_KEY', 'your-openweather-key-here')

    # File Uploads
    UPLOAD_FOLDER      = os.path.join(os.path.dirname(__file__), 'static', 'uploads')
    MAX_CONTENT_LENGTH = 10 * 1024 * 1024
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp'}
