"""
AI Client — Google Gemini (Free)
Replaces Anthropic Claude API
"""
import google.generativeai as genai

def get_gemini(api_key: str):
    genai.configure(api_key=api_key)
    return genai.GenerativeModel('gemini-1.5-flash')

def get_gemini_vision(api_key: str):
    genai.configure(api_key=api_key)
    return genai.GenerativeModel('gemini-1.5-flash')
