from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from models import User
from extensions import db

auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        data = request.get_json() if request.is_json else request.form

        name       = data.get('name', '').strip()
        phone      = data.get('phone', '').strip()
        email      = data.get('email', '').strip() or None
        password   = data.get('password', '')
        state      = data.get('state', 'Maharashtra')
        district   = data.get('district', 'Nashik')
        land_size  = data.get('land_size', 'small')
        primary_crop = data.get('primary_crop', 'Onion')

        if not name or not phone or not password:
            msg = 'Name, phone and password are required.'
            if request.is_json:
                return jsonify({'success': False, 'message': msg}), 400
            flash(msg, 'error')
            return redirect(url_for('auth.register'))

        if User.query.filter_by(phone=phone).first():
            msg = 'Phone number already registered.'
            if request.is_json:
                return jsonify({'success': False, 'message': msg}), 400
            flash(msg, 'error')
            return redirect(url_for('auth.register'))

        user = User(
            name=name, phone=phone, email=email,
            state=state, district=district,
            land_size=land_size, primary_crop=primary_crop
        )
        user.set_password(password)
        db.session.add(user)
        db.session.commit()

        session['user_id']   = user.id
        session['user_name'] = user.name

        if request.is_json:
            return jsonify({'success': True, 'redirect': url_for('main.dashboard')})
        return redirect(url_for('main.dashboard'))

    return render_template('register.html')


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        data     = request.get_json() if request.is_json else request.form
        phone    = data.get('phone', '').strip()
        password = data.get('password', '')

        user = User.query.filter_by(phone=phone).first()

        if user and user.check_password(password):
            session['user_id']   = user.id
            session['user_name'] = user.name
            if request.is_json:
                return jsonify({'success': True, 'redirect': url_for('main.dashboard')})
            return redirect(url_for('main.dashboard'))

        msg = 'Invalid phone number or password.'
        if request.is_json:
            return jsonify({'success': False, 'message': msg}), 401
        flash(msg, 'error')

    return render_template('login.html')


@auth_bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('main.index'))


@auth_bp.route('/delete-account', methods=['POST'])
def delete_account():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Not logged in'}), 401

    data     = request.get_json()
    password = (data or {}).get('password', '')

    user = User.query.get(session['user_id'])
    if not user:
        return jsonify({'success': False, 'message': 'Account not found'}), 404

    if not user.check_password(password):
        return jsonify({'success': False, 'message': 'Incorrect password. Please try again.'}), 401

    # Delete all related records first
    from models import DiseaseScan, SchemeSearch
    DiseaseScan.query.filter_by(user_id=user.id).delete()
    SchemeSearch.query.filter_by(user_id=user.id).delete()
    db.session.delete(user)
    db.session.commit()

    session.clear()
    return jsonify({'success': True})
